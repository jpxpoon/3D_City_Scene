ECS 175
Assignment 4

Jonathan Poon

Email:	jpxpoon@ucdavis.edu
Student ID:	997403574


Commands to create makefile compile run:

cmake .
make
./assignment4.x


KEY:
 1:	enable / disable car1 view 
 2:	enable / disable car2 view
 +:	move camera up
 -:	move camera down
 arrow keys:	move camera position

 esc / q:	quit program

Mouse:
 Press and hold Left button on the mouse and move around to change view-angle of camera

I use MilkshapeModel from "Brett Porter" to render the object.
References are on header of MilkshapeModel.cpp

Thank you.

