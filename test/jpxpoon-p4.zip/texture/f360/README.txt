This Model was downloaded from 3D-Resources.com
http://www.3d-resources.com

Software : Milkshape 3D

Contents of this file 

f360.ms3d
fskin.jpg
fsking.jpg
fskingr.jpg
fskiny.jpg

Credit for this model goes out to : Psionic

Hope to see you back soon on 

3D-Resources.com
