This Texture was downloaded from 3D-Resources.com
http://www.3d-resources.com

Contents of this file :

bluesky.jpg
README.txt

Hope to see you back soon on 

3D-Resources.com

